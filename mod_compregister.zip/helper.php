<?php
defined('_JEXEC') or die('Access denied');
class Computer {
	private $macaddress; //id
	private $firstname;
	private $lastname;
	private $email;
	private $room;
	private $fixedIP;
	private $comment;

	public function getMACaddress() {
		return $this->macaddress;
	}
	public function getFirstname(){
		return $this->firstname;
	}
	public function getLastname(){
		return $this->lastname;
	}
	public function getEmail(){
		return $this->email;
	}
	public function getRoom(){
		return $this->room;
	}
	public function getFixedIP(){
		return $this->fixedIP;
	}
	public function getComment(){
		return $this->comment;
	}
	public function setMACaddress($mac) {
		$this->macaddress = $this->convertToMAC($mac);
	}
	public function setFirstname($firstname) {
		$this->firstname=$firstname;
	}
	public function setLastname($lastname) {
		$this->lastname=$lastname;
	}
	public function setEmail($email) {
		$this->email=$email;
	}
	public function setRoom($room) {
		$this->room=$room;
	}
	public function setFixedIP($fixedIP) {
		$this->fixedIP=$fixedIP;
	}
	public function setComment($comment) {
		$this->comment=$comment;
	}
	private function convertToMAC($input) {
		$pattern="/^([0-9a-fA-F]{2}[:-]){5}([0-9a-fA-F]{2})$/";
		if(preg_match($pattern,$input) == 1) {
			$chars = explode("-", $input);
		} else { //$pattern =  "/^[0-9a-fA-F]{12}$/"
			$chars = str_split($input, 2);
		}
		$result = implode(":", $chars);
		return strtolower($result);
	}
}

class ModCompRegister {
	public static function saveData($computer, $params) {
		$db=JFactory::getDBO();
		$query="INSERT INTO `#__comp_register`(
				`macaddress`,
				`firstname`,
				`lastname`,
				`email`,
				`room`,
				`fixedip`,
				`comment`
				) 
				VALUES ('"
				.$computer->getMACaddress()		."', '"
				.$computer->getFirstname()		."', '"
				.$computer->getLastname()		."', '"
				.$computer->getEmail()			."', '"
				.$computer->getRoom()			."', '"
				.$computer->getFixedIP()		."', '"
				.$computer->getComment()		."')"
		;

		$db->setQuery($query);
		if($db->query()) {
			return true;
		}else{
			return false;
		}
	}

	public static function findMAC($mac) {
		$db=JFactory::getDBO();
		$query="SELECT COUNT(*) FROM `#__comp_register` WHERE macaddress = '$mac'";
		$db->setQuery($query);
		$count = $db->loadResult();
		if($count==0) {
			return false;
		} else {
			return true;
		}
	}

	public static function sendEmailNotification($computer,$params) {
		$mailer=JFactory::getMailer();
		$config=JFactory::getConfig();
		$sender=array($params->get('sender_email'),$params->get('sender_name'));
		$mailer->setSender($sender);
		$mailer->addRecipient($params->get('receiver_email'));
		$mailer->setSubject("Nowy formularz rejestracji komputera.");
		
		$body="<h3>Przysłano nowy formularz rejestracji:</h3><br />";
		$body.="Czas rejestracji: ".date("Y-m-d H:i:s")."<br />";
		$body.="Adres MAC: ".$computer->getMACaddress()."<br />";
		$body.="Stały IP: ".$computer->getFixedIP()."<br />";
		$body.="Użytkownik: ".$computer->getLastname()." ".$computer->getFirstname()."<br />";
		$body.="Email użytkownika: ".$computer->getEmail()."@ippt.pan.pl<br />";
		$body.="Miejsce podłączenia: pokój ".$computer->getRoom()."<br />";
		$body.="Uwagi: ".$computer->getComment()."<br />";
		$body.="<br />";
		$body.="<h3>Wpis do <em>dhcp.conf:</em></h3><br />";
		$body.="<br />";
		$body.="# ".date("d.m.Y")."; ".$computer->getFirstname()." ".$computer->getLastname()
			."; p".$computer->getRoom()."<br />";
		$body.="host "."komp".date("YmdHis")." { hardware ethernet ".$computer->getMACaddress();
		/*if($computer->getFixedIP() == "yes") {
			$body.="; fixed-address 0.0.0.0";
		}*/
		$body.="; }";
		$body.="<br />";

		$mailer->setBody($body);
		$mailer->isHTML(true);
		$mailer->send();
	}
}


?>